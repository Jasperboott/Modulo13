If you would like to contribute to the project as a developer, follow these instructions to get started:

Fork the EQTransformer project (https://github.com/smousavi05/EQTransformer)
Create your feature branch (git checkout -b my-new-feature)
Commit your changes (git commit -am 'Add some feature')
Push to the branch (git push origin my-new-feature)
Create a new Pull Request
